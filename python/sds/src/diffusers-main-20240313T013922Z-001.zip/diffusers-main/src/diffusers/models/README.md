# Models

For more detail on the models, please refer to the [docs](https://huggingface.co/docs/diffusers/api/models/overview).