## Diffusers examples with ONNXRuntime optimizations

**This research project is not actively maintained by the diffusers team. For any questions or comments, please contact Isamu Isozaki(isamu-isozaki) on github with any questions.**

The aim of this project is to provide retrieval augmented diffusion models to diffusers!